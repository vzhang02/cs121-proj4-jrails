package jrails;

public class Html {
    private String text;

    public Html() {
        this.text = "";
    }
    public Html(String text) {
        this.text = text;
    }

    public String toString() {
        return text;
    }

    public Html seq(Html h) {
        return new Html(text + h.toString());
    }

    public Html br() {
        return this.seq(View.br());
    }

    public Html t(Object o) {
        return this.seq(View.t(o));
    }

    public Html p(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html div(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html strong(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html h1(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html tr(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html th(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html td(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html table(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html thead(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html tbody(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html textarea(String name, Html child) {
        throw new UnsupportedOperationException();
    }

    public Html link_to(String text, String url) {
        throw new UnsupportedOperationException();
    }

    public Html form(String action, Html child) {
        throw new UnsupportedOperationException();
    }

    public Html submit(String value) {
        throw new UnsupportedOperationException();
    }
}